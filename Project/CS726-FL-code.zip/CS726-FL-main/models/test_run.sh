python3 main.py -dataset synthetic -model log_reg --eval-every 10 --num-rounds 100 --clients-per-round 5
